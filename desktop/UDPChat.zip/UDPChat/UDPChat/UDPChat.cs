﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using nsoftware.IPWorks;
using System.Diagnostics;
using nsoftware.IPWorksEncrypt;
namespace UDPChat
{
  // when open, active both 55550 and 55551 for gorup/direct messaging
  // udpDirect Data in will fire when a direct message is recvd
  //       Check for open conversations with alias from recvd message
  //              if none exists, create and shift focus
  //              if exists, add text and add asterisk to title

  public partial class UDPChat : Form
  {
    nsoftware.IPWorks.Udpport udpport, udpport_dm;
    string[] known, inordercolors, alias;
    private int ipx, ex_idx;
    private string key_pass;
    private TabPage[] extra_tabpages;
    private TabPage newpage;

    public UDPChat()
    {
      InitializeComponent();
      key_pass = "4NGZ0POKSJHDLAKSJHDLAKS85IJ4ZX2SD3M3TLS1WPNSJDHKFCV3DH";
      known = new string[30];
      inordercolors = new string[30];
      alias = new string[30];
      extra_tabpages = new TabPage[30];
      ipx = 0;
      ex_idx = 0;

      ListViewItem lvi = new ListViewItem(new string[] {"reese", "10.0.1.109", "blue"});
      listViewFriends.Items.Add(lvi);
      addBuddy("10.0.1.109", "blue", "reese");

      this.udpport = new Udpport();
      this.udpport.Active = false;
      this.udpport.InvokeThrough = this;
      this.udpport.OnDataIn += new nsoftware.IPWorks.Udpport.OnDataInHandler(this.udpport_OnDataIn);
      this.udpport.LocalPort = 55550;
      this.udpport.Active = true;
      this.udpport.AcceptData = true;

      //dm
      this.udpport_dm = new Udpport();
      this.udpport_dm.Active = false;
      this.udpport_dm.InvokeThrough = this;
      this.udpport_dm.OnDataIn += new nsoftware.IPWorks.Udpport.OnDataInHandler(this.udpportDirect_OnDataIn);
      this.udpport_dm.LocalPort = 55551;
      this.udpport_dm.Active = true;
      this.udpport_dm.AcceptData = true;
      toolStripStatusLabel1.Text = "Active";


    }
    private void appendTabPage(TabPage tp)
    {
      extra_tabpages[ex_idx] = tp;
      ex_idx++;
    }

    private TabPage getNewDMPage(string als)
    {
      System.Windows.Forms.TabPage tabPage2 = new System.Windows.Forms.TabPage();
      System.Windows.Forms.GroupBox groupBox3 = new System.Windows.Forms.GroupBox();
      System.Windows.Forms.GroupBox groupBox2 = new System.Windows.Forms.GroupBox();
      System.Windows.Forms.Button txtSendDirect = new System.Windows.Forms.Button();
      System.Windows.Forms.TextBox tbSendDirect = new System.Windows.Forms.TextBox();
      System.Windows.Forms.RichTextBox rtbDirectChatWindow = new System.Windows.Forms.RichTextBox();
      System.Windows.Forms.Button btnEndConversation = new System.Windows.Forms.Button();
      System.Windows.Forms.TextBox tbSendAlias = new System.Windows.Forms.TextBox();
      groupBox3.SuspendLayout();
      groupBox2.SuspendLayout();
      tabPage2.SuspendLayout();
      // 
      // groupBox3
      // 
      groupBox3.Controls.Add(txtSendDirect);
      groupBox3.Controls.Add(tbSendDirect);
      groupBox3.Controls.Add(rtbDirectChatWindow);
      groupBox3.Location = new System.Drawing.Point(4, 70);
      groupBox3.Name = "groupBox3";
      groupBox3.Size = new System.Drawing.Size(431, 355);
      groupBox3.TabIndex = 1;
      groupBox3.TabStop = false;
      groupBox3.Text = "Chat";
      // 
      // txtSendDirect
      // 
      txtSendDirect.Location = new System.Drawing.Point(361, 327);
      txtSendDirect.Name = "txtSendDirect";
      txtSendDirect.Size = new System.Drawing.Size(64, 20);
      txtSendDirect.TabIndex = 3;
      txtSendDirect.Text = "Send";
      txtSendDirect.UseVisualStyleBackColor = true;
      // 
      // tbSendAlias
      // 
      tbSendAlias.Location = new System.Drawing.Point(44, 22);
      tbSendAlias.Name = "tbSendAlias";
      tbSendAlias.Text = als;
      tbSendAlias.Size = new System.Drawing.Size(100, 20);
      tbSendAlias.TabIndex = 0;
      if (!als.Equals("")) { tbSendAlias.Enabled = false; }
      // 
      // tbSendDirect
      // 
      tbSendDirect.Location = new System.Drawing.Point(8, 328);
      tbSendDirect.Name = "tbSendDirect";
      tbSendDirect.Size = new System.Drawing.Size(343, 20);
      tbSendDirect.TabIndex = 2;
      // 
      // rtbDirectChatWindow
      // 
      rtbDirectChatWindow.Location = new System.Drawing.Point(8, 19);
      rtbDirectChatWindow.Name = "rtbDirectChatWindow";
      rtbDirectChatWindow.Size = new System.Drawing.Size(417, 303);
      rtbDirectChatWindow.TabIndex = 1;
      rtbDirectChatWindow.Text = "";
      // 
      // groupBox2
      // 
      groupBox2.Controls.Add(btnEndConversation);
      groupBox2.Controls.Add(label1);
      groupBox2.Controls.Add(tbSendAlias);
      groupBox2.Location = new System.Drawing.Point(3, 3);
      groupBox2.Name = "groupBox2";
      groupBox2.Size = new System.Drawing.Size(432, 61);
      groupBox2.TabIndex = 0;
      groupBox2.TabStop = false;
      groupBox2.Text = "Contact";
      // 
      // btnEndConversation
      // 
      btnEndConversation.Location = new System.Drawing.Point(319, 20);
      btnEndConversation.Name = "btnEndConversation";
      btnEndConversation.Size = new System.Drawing.Size(107, 23);
      btnEndConversation.TabIndex = 2;
      btnEndConversation.Text = "End Conversation";
      btnEndConversation.UseVisualStyleBackColor = true;
      btnEndConversation.Click += new System.EventHandler(btnEndConversation_Click);
      // 
      // tabPage2
      // 
      tabPage2.Controls.Add(groupBox3);
      tabPage2.Controls.Add(groupBox2);
      tabPage2.Location = new System.Drawing.Point(4, 22);
      tabPage2.Name = "tabPage2";
      tabPage2.Size = new System.Drawing.Size(439, 428);
      tabPage2.TabIndex = 1;
      tabPage2.Text = "  " + als + "   " ;
      tabPage2.UseVisualStyleBackColor = true;

      groupBox3.ResumeLayout(false);
      groupBox3.PerformLayout();
      groupBox2.ResumeLayout(false);
      groupBox2.PerformLayout();

      return tabPage2;
    }
    // helper fxns
    private void log(string msg)
    {
      chatWindow.AppendText(msg);
      chatWindow.SelectionStart = chatWindow.TextLength;
      chatWindow.SelectionLength = msg.Length;
      chatWindow.SelectionColor = Color.Black;
    }

    private void logmsg(string ip, string msg)
    {
      string formatted_msg = ip_to_buddy(ip) + ": " + msg + "\n";
      chatWindow.Select(chatWindow.TextLength, 0);
      chatWindow.SelectionColor = ip_to_color(ip);
      chatWindow.AppendText(formatted_msg);
    }

    private Color ip_to_color(string ip)
    {
      string color_string;
      try
      {
        color_string = inordercolors[Array.IndexOf(known, ip)];
      }
      catch (IndexOutOfRangeException e) { color_string = "black"; }
      switch (color_string)
      {
        case "aliceblue":
          return Color.AliceBlue;
        case "lightsalmon":
          return Color.LightSalmon;
        case "antiquewhite":
          return Color.AntiqueWhite;
        case "lightseagreen":
          return Color.LightSeaGreen;
        case "aqua":
          return Color.Aqua;
        case "lightskyblue":
          return Color.LightSkyBlue;
        case "aquamarine":
          return Color.Aquamarine;
        case "lightslategray":
          return Color.LightSlateGray;
        case "azure":
          return Color.Azure;
        case "lightsteelblue":
          return Color.LightSteelBlue;
        case "beige":
          return Color.Beige;
        case "lightyellow":
          return Color.LightYellow;
        case "bisque":
          return Color.Bisque;
        case "lime":
          return Color.Lime;
        case "black":
          return Color.Black;
        case "limegreen":
          return Color.LimeGreen;
        case "blanchedalmond":
          return Color.BlanchedAlmond;
        case "linen":
          return Color.Linen;
        case "blue":
          return Color.Blue;
        case "magenta":
          return Color.Magenta;
        case "blueviolet":
          return Color.BlueViolet;
        case "maroon":
          return Color.Maroon;
        case "brown":
          return Color.Brown;
        case "mediumaquamarine":
          return Color.MediumAquamarine;
        case "burlywood":
          return Color.BurlyWood;
        case "mediumblue":
          return Color.MediumBlue;
        case "cadetblue":
          return Color.CadetBlue;
        case "mediumorchid":
          return Color.MediumOrchid;
        case "chartreuse":
          return Color.Chartreuse;
        case "mediumpurple":
          return Color.MediumPurple;
        case "chocolate":
          return Color.Chocolate;
        case "mediumseagreen":
          return Color.MediumSeaGreen;
        case "coral":
          return Color.Coral;
        case "mediumslateblue":
          return Color.MediumSlateBlue;
        case "cornflowerblue":
          return Color.CornflowerBlue;
        case "mediumspringgreen":
          return Color.MediumSpringGreen;
        case "cornsilk":
          return Color.Cornsilk;
        case "mediumturquoise":
          return Color.MediumTurquoise;
        case "crimson":
          return Color.Crimson;
        case "mediumvioletred":
          return Color.MediumVioletRed;
        case "cyan":
          return Color.Cyan;
        case "midnightblue":
          return Color.MidnightBlue;
        case "darkblue":
          return Color.DarkBlue;
        case "mintcream":
          return Color.MintCream;
        case "darkcyan":
          return Color.DarkCyan;
        case "mistyrose":
          return Color.MistyRose;
        case "darkgoldenrod":
          return Color.DarkGoldenrod;
        case "moccasin":
          return Color.Moccasin;
        case "darkgray":
          return Color.DarkGray;
        case "navajowhite":
          return Color.NavajoWhite;
        case "darkgreen":
          return Color.DarkGreen;
        case "navy":
          return Color.Navy;
        case "darkKhaki":
          return Color.DarkKhaki;
        case "oldlace":
          return Color.OldLace;
        case "darkmagetna":
          return Color.DarkMagenta;
        case "olive":
          return Color.Olive;
        case "darkolivegreen":
          return Color.DarkOliveGreen;
        case "olivedrab":
          return Color.OliveDrab;
        case "darkorange":
          return Color.DarkOrange;
        case "orange":
          return Color.Orange;
        case "darkorchid":
          return Color.DarkOrchid;
        case "orangered":
          return Color.OrangeRed;
        case "darkred":
          return Color.DarkRed;
        case "orchid":
          return Color.Orchid;
        case "darksalmon":
          return Color.DarkSalmon;
        case "palegoldenrod":
          return Color.PaleGoldenrod;
        case "darkseagreen":
          return Color.DarkSeaGreen;
        case "palegreen":
          return Color.PaleGreen;
        case "darkslateblue":
          return Color.DarkSlateBlue;
        case "paleturquoise":
          return Color.PaleTurquoise;
        case "darkslategray":
          return Color.DarkSlateGray;
        case "palevioletred":
          return Color.PaleVioletRed;
        case "darkturquoise":
          return Color.DarkTurquoise;
        case "papayawhip":
          return Color.PapayaWhip;
        case "darkviolet":
          return Color.DarkViolet;
        case "peachpuff":
          return Color.PeachPuff;
        case "deeppink":
          return Color.DeepPink;
        case "peru":
          return Color.Peru;
        case "deepskyblue":
          return Color.DeepSkyBlue;
        case "pink":
          return Color.Pink;
        case "dimgray":
          return Color.DimGray;
        case "plum":
          return Color.Plum;
        case "dodgerblue":
          return Color.DodgerBlue;
        case "powderblue":
          return Color.PowderBlue;
        case "firebrick":
          return Color.Firebrick;
        case "purple":
          return Color.Purple;
        case "floralwhite":
          return Color.FloralWhite;
        case "red":
          return Color.Red;
        case "forestgreen":
          return Color.ForestGreen;
        case "rosybrown":
          return Color.RosyBrown;
        case "fuchsia":
          return Color.Fuchsia;
        case "royalblue":
          return Color.RoyalBlue;
        case "gainsboro":
          return Color.Gainsboro;
        case "saddlebrown":
          return Color.SaddleBrown;
        case "ghostwhite":
          return Color.GhostWhite;
        case "salmon":
          return Color.Salmon;
        case "gold":
          return Color.Gold;
        case "sandybrown":
          return Color.SandyBrown;
        case "goldenrod":
          return Color.Goldenrod;
        case "seagreen":
          return Color.SeaGreen;
        case "gray":
          return Color.Gray;
        case "seashell":
          return Color.SeaShell;
        case "green":
          return Color.Green;
        case "sienna":
          return Color.Sienna;
        case "greenyellow":
          return Color.GreenYellow;
        case "dilver":
          return Color.Silver;
        case "honeydew":
          return Color.Honeydew;
        case "dkyblue":
          return Color.SkyBlue;
        case "hotpink":
          return Color.HotPink;
        case "slateblue":
          return Color.SlateBlue;
        case "indianred":
          return Color.IndianRed;
        case "slategray":
          return Color.SlateGray;
        case "indigo":
          return Color.Indigo;
        case "snow":
          return Color.Snow;
        case "ivory":
          return Color.Ivory;
        case "springgreen":
          return Color.SpringGreen;
        case "khaki":
          return Color.Khaki;
        case "steelblue":
          return Color.SteelBlue;
        case "lavender":
          return Color.Lavender;
        case "tan":
          return Color.Tan;
        case "lavenderblush":
          return Color.LavenderBlush;
        case "teal":
          return Color.Teal;
        case "lawngreen":
          return Color.LawnGreen;
        case "thistle":
          return Color.Thistle;
        case "lemonchiffon":
          return Color.LemonChiffon;
        case "tomato":
          return Color.Tomato;
        case "lightblue":
          return Color.LightBlue;
        case "turquoise":
          return Color.Turquoise;
        case "lightcoral":
          return Color.LightCoral;
        case "violet":
          return Color.Violet;
        case "lightcyan":
          return Color.LightCyan;
        case "wheat":
          return Color.Wheat;
        case "lightgoldenrodyellow":
          return Color.LightGoldenrodYellow;
        case "white":
          return Color.White;
        case "lightgreen":
          return Color.LightGreen;
        case "whitesmoke":
          return Color.WhiteSmoke;
        case "lightgray":
          return Color.LightGray;
        case "yellow":
          return Color.Yellow;
        case "lightpink":
          return Color.LightPink;
        case "yellowgreen":
          return Color.YellowGreen;
        default:
          return Color.Black;
      }
    }

    private string ip_to_buddy(string ip)
    {
      try {
        if (alias[Array.IndexOf(known, ip)].Equals("")) { return ip; }
        else { return alias[Array.IndexOf(known, ip)]; }
        } catch (System.IndexOutOfRangeException e) { return ip; }
    }

    private string buddy_to_ip(string als)
    {
      try { return known[Array.IndexOf(alias, als)]; } catch (System.IndexOutOfRangeException e) { return als; }
    }

    private void sendAll(string msg)
    {
      for (int i = 0; i < ipx; i++) // not working sending to all
      {
        udpport.RemoteHost = known[i];
        udpport.RemotePort = 55550;
        udpport.DataToSend = msg;
      }
    }

    private void sendOne(string msg, string ip)
    {
      udpport.RemoteHost = ip;
      udpport.RemotePort = 55551;
      udpport.DataToSend = msg;
    }

    private void addBuddy(string ip, string color, string nick)
    {
      known[ipx] = ip;
      inordercolors[ipx] = color;
      alias[ipx] = nick;
      ipx++;
    }

    // events

    private void genericBtnSendClick(object sender, EventArgs e, TabPage tpage)
    {
      ((RichTextBox)tpage.Controls[0].Controls[2]).AppendText("You>  " + tpage.Controls[0].Controls[1].Text + "\n"); // make a generic method for this too
      Ezcrypt ez = new Ezcrypt();
      ez.Algorithm = EzcryptAlgorithms.ezAES;
      ez.KeyPassword = key_pass;
      ez.InputMessage = tpage.Controls[0].Controls[1].Text;
      ez.Encrypt();

      //MessageBox.Show("Sending " + tpage.Controls[0].Controls[1].Text + " encrypted as " + ez.OutputMessage + " to " + buddy_to_ip(tpage.Controls[1].Controls[2].Text));
      sendOne(ez.OutputMessage, buddy_to_ip(tpage.Controls[1].Controls[2].Text));
      tpage.Controls[0].Controls[1].Text = "";
    }

    private void buttonSend_Click(object sender, EventArgs e)
    {
      chatWindow.AppendText("You>  " + textSend.Text + "\n");
      Ezcrypt ez = new Ezcrypt();
      ez.Algorithm = EzcryptAlgorithms.ezAES;
      ez.KeyPassword = key_pass;
      ez.InputMessage = textSend.Text;
      ez.Encrypt();


      sendAll(ez.OutputMessage);
      textSend.Text = "";

    }

    private void toolStripButton2_Click(object sender, EventArgs e)
    {
      Add a = new Add();
      a.ShowDialog();
      if (!a.cancelled)
      {
        ListViewItem lvi = new ListViewItem(new string[] { a.textAlias.Text, a.textIP.Text, a.textColor.Text });
        listViewFriends.Items.Add(lvi);

        addBuddy(a.textIP.Text, a.textColor.Text, a.textAlias.Text);
      }
    }

    private void udpport_OnDataIn(object sender, UdpportDataInEventArgs e)
    {
      int length = chatWindow.TextLength;

      Ezcrypt ez = new Ezcrypt();
      ez.Algorithm = EzcryptAlgorithms.ezAES;
      ez.KeyPassword = key_pass;
      ez.InputMessage = e.Datagram;
      ez.Decrypt();

      logmsg(e.SourceAddress, ez.OutputMessage);
    }

    private void udpportDirect_OnDataIn(object sender, UdpportDataInEventArgs e)
    {
      int length = chatWindow.TextLength;
      int ex_idx_frozen = ex_idx;
      string from = ip_to_buddy(e.SourceAddress);
      Ezcrypt ez = new Ezcrypt();
      ez.Algorithm = EzcryptAlgorithms.ezAES;
      ez.KeyPassword = key_pass;
      ez.InputMessage = e.Datagram;
      ez.Decrypt();



      // find a better way to do this, sometimes throws ArgumentOutOfRange for Controls[2]
      for (int i = 0; i < ex_idx_frozen; i++)
      {
        MessageBox.Show(extra_tabpages[i].Text + ", " +  from);
        if (extra_tabpages[i].Text.Equals(from)) // IF 3 A TABPAGE WITH ALIAS OPEN ALREADY
        {
          ((RichTextBox)extra_tabpages[i].Controls[0].Controls[2]).AppendText(from + ": " + ez.OutputMessage + "\n");
          // MAKE VISUAL NEW MESSAGE CUE
        }
        else { // case ex_idx != 0, but not existing tab page
          newpage = getNewDMPage(from);
          newpage.Controls[0].Controls[0].Click += (s, ev) => genericBtnSendClick(s, ev, newpage);
          newpage.Controls[0].Controls[1].KeyPress += (s, ev) => genericTextSend_KeyPress(s, ev, newpage);
          tcControl.Controls.Add(newpage);
          appendTabPage(newpage);
          ((RichTextBox)newpage.Controls[0].Controls[2]).AppendText(from + ": " + ez.OutputMessage + "\n");
        }
      }
      if (ex_idx == 0)
      {
        newpage = getNewDMPage(from);
        newpage.Controls[0].Controls[0].Click += (s, ev) => genericBtnSendClick(s, ev, newpage);
        newpage.Controls[0].Controls[1].KeyPress += (s, ev) => genericTextSend_KeyPress(s, ev, newpage);
        tcControl.Controls.Add(newpage);
        appendTabPage(newpage);
        ((RichTextBox)newpage.Controls[0].Controls[2]).AppendText(from + ": " + ez.OutputMessage + "\n");
        //CHANGE FOCUS TO NEW PAGE OR ADD VISUAL CUE
      }

    }

    private void chatWindow_TextChanged(object sender, EventArgs e)
    {
      chatWindow.SelectionStart = chatWindow.Text.Length;
      chatWindow.ScrollToCaret();
    }

    private void btnEndConversation_Click(object sender, EventArgs e)
    {
      tcControl.TabPages.RemoveAt(tcControl.SelectedIndex);
      ex_idx--;
      // close socket, end convo, do anything else required to end
    }

    private void listViewFriends_DoubleClick(object sender, EventArgs e)
    {

      int i = listViewFriends.SelectedIndices[0];
      string a = alias[i];
      newpage = getNewDMPage(a);
      newpage.Controls[0].Controls[0].Click += (s, ev) => genericBtnSendClick(s, ev, newpage);
      tcControl.Controls.Add(newpage);
      appendTabPage(newpage);
    }

    private void Form1_Closing(object sender, System.ComponentModel.CancelEventArgs e)
    {
      udpport.Active = false;
      udpport_dm.Active = false;
    }

    private void genericTextSend_KeyPress(Object sender, System.Windows.Forms.KeyPressEventArgs e, TabPage tp) {
      if (e.KeyChar == 13)
      {
        ((RichTextBox)tp.Controls[0].Controls[2]).AppendText("You>  " + textSend.Text + "\n");
        Ezcrypt ez = new Ezcrypt();
        ez.Algorithm = EzcryptAlgorithms.ezAES;
        ez.KeyPassword = key_pass;
        ez.InputMessage = newpage.Controls[0].Controls[1].Text;
        ez.Encrypt();
        sendOne(ez.OutputMessage, buddy_to_ip(tp.Controls[1].Controls[2].Text));
        textSend.Text = "";
      }
    }

    private void textSend_KeyPress(Object sender, System.Windows.Forms.KeyPressEventArgs e)
    {
      if (e.KeyChar == 13)
      {
        chatWindow.AppendText("You>  " + textSend.Text + "\n");
        Ezcrypt ez = new Ezcrypt();
        ez.Algorithm = EzcryptAlgorithms.ezAES;
        ez.KeyPassword = key_pass;
        ez.InputMessage = textSend.Text;
        ez.Encrypt();
        sendAll(ez.OutputMessage);
        textSend.Text = "";
      }
    }
  }
}

