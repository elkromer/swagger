﻿namespace UDPChat
{
    partial class UDPChat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UDPChat));
      this.statusStrip1 = new System.Windows.Forms.StatusStrip();
      this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.btnMessage = new System.Windows.Forms.ToolStripDropDownButton();
      this.tsmiNewMessage = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.listViewFriends = new System.Windows.Forms.ListView();
      this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
      this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
      this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
      this.groupBoxChat = new System.Windows.Forms.GroupBox();
      this.chatWindow = new System.Windows.Forms.RichTextBox();
      this.buttonSend = new System.Windows.Forms.Button();
      this.textSend = new System.Windows.Forms.TextBox();
      this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
      this.tcControl = new System.Windows.Forms.TabControl();
      this.tabPage1 = new System.Windows.Forms.TabPage();
      this.label1 = new System.Windows.Forms.Label();
      this.tabPage2 = new System.Windows.Forms.TabPage();
      this.groupBox3 = new System.Windows.Forms.GroupBox();
      this.txtSendDirect = new System.Windows.Forms.Button();
      this.tbSendDirect = new System.Windows.Forms.TextBox();
      this.rtbDirectChatWindow = new System.Windows.Forms.RichTextBox();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.btnEndConversation = new System.Windows.Forms.Button();
      this.tbSendAlias = new System.Windows.Forms.TextBox();
      this.statusStrip1.SuspendLayout();
      this.toolStrip1.SuspendLayout();
      this.groupBox1.SuspendLayout();
      this.groupBoxChat.SuspendLayout();
      this.tcControl.SuspendLayout();
      this.tabPage1.SuspendLayout();
      this.tabPage2.SuspendLayout();
      this.groupBox3.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.SuspendLayout();
      // 
      // statusStrip1
      // 
      this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
      this.statusStrip1.Location = new System.Drawing.Point(0, 478);
      this.statusStrip1.Name = "statusStrip1";
      this.statusStrip1.Size = new System.Drawing.Size(442, 22);
      this.statusStrip1.TabIndex = 0;
      this.statusStrip1.Text = "statusStrip1";
      // 
      // toolStripStatusLabel1
      // 
      this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
      this.toolStripStatusLabel1.Size = new System.Drawing.Size(48, 17);
      this.toolStripStatusLabel1.Text = "Inactive";
      // 
      // toolStrip1
      // 
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton2,
            this.toolStripSeparator1,
            this.btnMessage,
            this.toolStripSeparator2});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(442, 25);
      this.toolStrip1.TabIndex = 4;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // toolStripButton2
      // 
      this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
      this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
      this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.toolStripButton2.Name = "toolStripButton2";
      this.toolStripButton2.Size = new System.Drawing.Size(33, 22);
      this.toolStripButton2.Text = "Add";
      this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
      // 
      // btnMessage
      // 
      this.btnMessage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
      this.btnMessage.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiNewMessage});
      this.btnMessage.Image = ((System.Drawing.Image)(resources.GetObject("btnMessage.Image")));
      this.btnMessage.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.btnMessage.Name = "btnMessage";
      this.btnMessage.Size = new System.Drawing.Size(66, 22);
      this.btnMessage.Text = "Message";
      // 
      // tsmiNewMessage
      // 
      this.tsmiNewMessage.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
      this.tsmiNewMessage.Name = "tsmiNewMessage";
      this.tsmiNewMessage.Size = new System.Drawing.Size(147, 22);
      this.tsmiNewMessage.Text = "New Message";
      this.tsmiNewMessage.ToolTipText = "Send a new message to a person in your buddy list";
      // 
      // toolStripSeparator2
      // 
      this.toolStripSeparator2.Name = "toolStripSeparator2";
      this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.listViewFriends);
      this.groupBox1.Location = new System.Drawing.Point(6, 6);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(425, 136);
      this.groupBox1.TabIndex = 5;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Friends";
      // 
      // listViewFriends
      // 
      this.listViewFriends.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
      this.listViewFriends.Location = new System.Drawing.Point(6, 19);
      this.listViewFriends.MultiSelect = false;
      this.listViewFriends.Name = "listViewFriends";
      this.listViewFriends.Size = new System.Drawing.Size(413, 111);
      this.listViewFriends.TabIndex = 0;
      this.listViewFriends.UseCompatibleStateImageBehavior = false;
      this.listViewFriends.View = System.Windows.Forms.View.Details;
      this.listViewFriends.DoubleClick += new System.EventHandler(this.listViewFriends_DoubleClick);
      // 
      // columnHeader1
      // 
      this.columnHeader1.Text = "Name";
      this.columnHeader1.Width = 61;
      // 
      // columnHeader2
      // 
      this.columnHeader2.Text = "Ip";
      this.columnHeader2.Width = 100;
      // 
      // columnHeader3
      // 
      this.columnHeader3.Text = "Color";
      this.columnHeader3.Width = 110;
      // 
      // groupBoxChat
      // 
      this.groupBoxChat.Controls.Add(this.chatWindow);
      this.groupBoxChat.Controls.Add(this.buttonSend);
      this.groupBoxChat.Controls.Add(this.textSend);
      this.groupBoxChat.Location = new System.Drawing.Point(6, 148);
      this.groupBoxChat.Name = "groupBoxChat";
      this.groupBoxChat.Size = new System.Drawing.Size(425, 275);
      this.groupBoxChat.TabIndex = 6;
      this.groupBoxChat.TabStop = false;
      this.groupBoxChat.Text = "Chat";
      // 
      // chatWindow
      // 
      this.chatWindow.Location = new System.Drawing.Point(6, 19);
      this.chatWindow.Name = "chatWindow";
      this.chatWindow.Size = new System.Drawing.Size(413, 224);
      this.chatWindow.TabIndex = 3;
      this.chatWindow.Text = "";
      // 
      // buttonSend
      // 
      this.buttonSend.Location = new System.Drawing.Point(355, 249);
      this.buttonSend.Name = "buttonSend";
      this.buttonSend.Size = new System.Drawing.Size(64, 20);
      this.buttonSend.TabIndex = 2;
      this.buttonSend.Text = "Send";
      this.buttonSend.UseVisualStyleBackColor = true;
      this.buttonSend.Click += new System.EventHandler(this.buttonSend_Click);
      // 
      // textSend
      // 
      this.textSend.Location = new System.Drawing.Point(6, 249);
      this.textSend.Name = "textSend";
      this.textSend.Size = new System.Drawing.Size(343, 20);
      this.textSend.TabIndex = 0;
      this.textSend.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textSend_KeyPress);
      // 
      // tcControl
      // 
      this.tcControl.Controls.Add(this.tabPage1);
      this.tcControl.Location = new System.Drawing.Point(0, 28);
      this.tcControl.Name = "tcControl";
      this.tcControl.SelectedIndex = 0;
      this.tcControl.Size = new System.Drawing.Size(447, 454);
      this.tcControl.TabIndex = 7;
      // 
      // tabPage1
      // 
      this.tabPage1.Controls.Add(this.groupBoxChat);
      this.tabPage1.Controls.Add(this.groupBox1);
      this.tabPage1.Location = new System.Drawing.Point(4, 22);
      this.tabPage1.Name = "tabPage1";
      this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
      this.tabPage1.Size = new System.Drawing.Size(439, 428);
      this.tabPage1.TabIndex = 0;
      this.tabPage1.Text = "  All Chat  ";
      this.tabPage1.UseVisualStyleBackColor = true;
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(6, 25);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(32, 13);
      this.label1.TabIndex = 1;
      this.label1.Text = "Alias:";
      // 
      // tabPage2
      // 
      this.tabPage2.Controls.Add(this.groupBox3);
      this.tabPage2.Controls.Add(this.groupBox2);
      this.tabPage2.Location = new System.Drawing.Point(4, 22);
      this.tabPage2.Name = "tabPage2";
      this.tabPage2.Size = new System.Drawing.Size(439, 428);
      this.tabPage2.TabIndex = 1;
      this.tabPage2.Text = "  New Message  ";
      this.tabPage2.UseVisualStyleBackColor = true;
      // 
      // groupBox3
      // 
      this.groupBox3.Controls.Add(this.txtSendDirect);
      this.groupBox3.Controls.Add(this.tbSendDirect);
      this.groupBox3.Controls.Add(this.rtbDirectChatWindow);
      this.groupBox3.Location = new System.Drawing.Point(4, 70);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new System.Drawing.Size(431, 355);
      this.groupBox3.TabIndex = 1;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "Chat";
      // 
      // txtSendDirect
      // 
      this.txtSendDirect.Location = new System.Drawing.Point(361, 327);
      this.txtSendDirect.Name = "txtSendDirect";
      this.txtSendDirect.Size = new System.Drawing.Size(64, 20);
      this.txtSendDirect.TabIndex = 3;
      this.txtSendDirect.Text = "Send";
      this.txtSendDirect.UseVisualStyleBackColor = true;
      // 
      // tbSendDirect
      // 
      this.tbSendDirect.Location = new System.Drawing.Point(8, 328);
      this.tbSendDirect.Name = "tbSendDirect";
      this.tbSendDirect.Size = new System.Drawing.Size(343, 20);
      this.tbSendDirect.TabIndex = 2;
      // 
      // rtbDirectChatWindow
      // 
      this.rtbDirectChatWindow.Location = new System.Drawing.Point(8, 19);
      this.rtbDirectChatWindow.Name = "rtbDirectChatWindow";
      this.rtbDirectChatWindow.Size = new System.Drawing.Size(417, 303);
      this.rtbDirectChatWindow.TabIndex = 1;
      this.rtbDirectChatWindow.Text = "";
      // 
      // groupBox2
      // 
      this.groupBox2.Controls.Add(this.btnEndConversation);
      this.groupBox2.Controls.Add(this.label1);
      this.groupBox2.Controls.Add(this.tbSendAlias);
      this.groupBox2.Location = new System.Drawing.Point(3, 3);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(432, 61);
      this.groupBox2.TabIndex = 0;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Contact";
      // 
      // btnEndConversation
      // 
      this.btnEndConversation.Location = new System.Drawing.Point(319, 20);
      this.btnEndConversation.Name = "btnEndConversation";
      this.btnEndConversation.Size = new System.Drawing.Size(107, 23);
      this.btnEndConversation.TabIndex = 2;
      this.btnEndConversation.Text = "End Conversation";
      this.btnEndConversation.UseVisualStyleBackColor = true;
      this.btnEndConversation.Click += new System.EventHandler(this.btnEndConversation_Click);
      // 
      // tbSendAlias
      // 
      this.tbSendAlias.Location = new System.Drawing.Point(44, 22);
      this.tbSendAlias.Name = "tbSendAlias";
      this.tbSendAlias.Size = new System.Drawing.Size(100, 20);
      this.tbSendAlias.TabIndex = 0;
      // 
      // UDPChat
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(442, 500);
      this.Controls.Add(this.toolStrip1);
      this.Controls.Add(this.statusStrip1);
      this.Controls.Add(this.tcControl);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.Name = "UDPChat";
      this.Text = "Encrypted UDP Chat";
      this.statusStrip1.ResumeLayout(false);
      this.statusStrip1.PerformLayout();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.groupBox1.ResumeLayout(false);
      this.groupBoxChat.ResumeLayout(false);
      this.groupBoxChat.PerformLayout();
      this.tcControl.ResumeLayout(false);
      this.tabPage1.ResumeLayout(false);
      this.tabPage2.ResumeLayout(false);
      this.groupBox3.ResumeLayout(false);
      this.groupBox3.PerformLayout();
      this.groupBox2.ResumeLayout(false);
      this.groupBox2.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBoxChat;
        private System.Windows.Forms.Button buttonSend;
        public System.Windows.Forms.TextBox textSend;
        private System.Windows.Forms.RichTextBox chatWindow;
        private System.Windows.Forms.ListView listViewFriends;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripDropDownButton btnMessage;
        private System.Windows.Forms.ToolStripMenuItem tsmiNewMessage;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        public System.Windows.Forms.TabControl tcControl;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label1;


        System.Windows.Forms.TabPage tabPage2;
        System.Windows.Forms.GroupBox groupBox3;
        System.Windows.Forms.GroupBox groupBox2;
        System.Windows.Forms.Button txtSendDirect;
        System.Windows.Forms.TextBox tbSendDirect;
        System.Windows.Forms.RichTextBox rtbDirectChatWindow;
        System.Windows.Forms.Button btnEndConversation;
        System.Windows.Forms.TextBox tbSendAlias;
    }
}

